import generateweather
from generateweather import check

check()